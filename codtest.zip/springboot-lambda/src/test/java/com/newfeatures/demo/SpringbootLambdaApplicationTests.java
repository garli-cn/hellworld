package com.newfeatures.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLambdaApplicationTests {

	@Test
	void contextLoads() {
	}

}
