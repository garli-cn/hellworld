package com.newfeatures.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootLambdaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootLambdaApplication.class, args);
		TheTwoStages tts = new TheTwoStages();
		String str = "abcccbad";
		System.out.println(tts.removeBBB(str));
	}


	public static String removeAAA(String str) {
		char ch = str.charAt(0);
		String newStr = "";
		int cnt = 0;
		String tmp = "";
		List<String> lst = new ArrayList<String>();
		newStr += ch;

		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i) == ch) {
				cnt++;

				if (cnt > 1) {
					tmp = String.format("%" + (cnt + 1) + "s", "").replace(' ', ch);
				}
			} else {
				if (cnt > 1) {
					lst.add(tmp);
				}
				cnt = 0;
			}
			newStr = newStr + str.charAt(i);
			ch = str.charAt(i);
		}

		if (newStr.length() < 3 || "".equals(tmp)) {
			return newStr;
		} else {
			for (int j = 0; j < lst.size(); j++) {
				newStr = newStr.replace(lst.get(j), "");
			}
			if (newStr.equals(tmp)) {
				return "";
			} else {
				return removeAAA(newStr);
			}
		}
	}
/////////TTT
	public static String replaceTTT(String str) {
		
		List<String> lst = new ArrayList();
		try {
			lst = traverseStr(str);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		if (str.length() < 3) {
//			return str;
//		} else {
		int ii = lst.size();
		
		if(ii>0) {
			for (int j = 0; j < lst.size(); j++) {
				str = str.replace(lst.get(j), "");
			}
			if (str.equals("aaa")) {
				return "";
			} else {
				return replaceTTT(str);
			}
		}else {
			return str;
		}
	}	

	///END TTT
	public static String removeBBB(String str) {
		char ch = str.charAt(0);

		if(str.chars().distinct().count() ==1) {
			if(ch=='a' && str.length()>2) {
				return "";
			}else if(str.length()<3) {
				return str;
			}else {
				return String.valueOf((char)((int)ch - 1));
			}
		}
		String newStr = "";
		int cnt = 0;
		String tmp = "";
		List<String> lst = new ArrayList<String>();
		newStr += ch;
		
		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i) == ch) {
				cnt++;
				if (cnt > 1) {
					tmp = String.format("%" + (cnt + 1) + "s", "").replace(' ', ch);
				}
			} else {
				if (cnt > 1 && !tmp.startsWith("a")) {
					lst.add(tmp);
				}
				cnt = 0;
			}
			newStr = newStr + str.charAt(i);
			ch = str.charAt(i);
		}

		if (newStr.length() < 3 || "".equals(tmp)|| newStr.equals(tmp)) {
			return newStr;
		} else {
			if(!"".equals(tmp)) {lst.add(tmp);}
			for (int j = 0; j < lst.size(); j++) {
				String lstItem = lst.get(j);
				if(!lstItem.isEmpty()) {
					String singleChr = "";
					if(lstItem.startsWith("a")) {
						singleChr = "";
					}else {
						singleChr = String.valueOf((char)((int)lstItem.charAt(0) - 1));
					}
					newStr = newStr.replace(lst.get(j),singleChr);
				}
			}

			if ("".equals(tmp)) {
				return newStr;
			} else {
				return removeBBB(newStr);
			}
		}
	}
	
	////////////////M
	private static List<String> traverseStr(String str){

		char ch = str.charAt(0);
		String newStr = "";
		int cnt = 0;
		String tmp = "";
		List<String> lst = new ArrayList<String>();
		newStr += ch;
		if (newStr.length() < 3 || "".equals(tmp)) {
			 lst.add("");
			 return lst;
		} 
		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i) == ch) {
				cnt++;
				if (cnt > 1) {
					tmp = String.format("%" + (cnt + 1) + "s", "").replace(' ', ch);
				}
			} else {
				if (cnt > 1) {
					lst.add(tmp);
				}
				cnt = 0;
			}
			newStr = newStr + str.charAt(i);
			ch = str.charAt(i);
		}

		System.out.println(str+"  "+tmp);
		return lst;
	}
}
